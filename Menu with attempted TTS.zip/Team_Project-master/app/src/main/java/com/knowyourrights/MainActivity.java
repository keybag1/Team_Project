package com.knowyourrights;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private Button MoneyButton;
    private Button HousingButton;
    private Button CommunicationButton;
    private Button EmploymentButton;
    TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Floating action button for TTS
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        //Button for money menu
        MoneyButton = findViewById(R.id.Money);
        MoneyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View mview) {
                MoneyMenu(mview);
            }
        });
        //Button for Housing Menu
        HousingButton = findViewById(R.id.Housing);
        HousingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View hview) {
                HousingMenu(hview);
            }
        });

        //Button for Communication Menu
        CommunicationButton = findViewById(R.id.Communication);
        CommunicationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View cview) {
                CommunicationMenu(cview);
            }
        });

        //Button for Employment Menu
        EmploymentButton = findViewById(R.id.Employment);
        EmploymentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View eview) {
                EmploymentMenu(eview);
            }
        });

    }

    //Money Menu Activity
    public void MoneyMenu(View mview) {
        Intent moneyIntent = new Intent(this, MoneyActivity.class);
        startActivity(moneyIntent);
    }

    //Housing Menu Activity
    public void HousingMenu(View hview) {
        Intent HousingIntent = new Intent(this, HousingActivity.class);
        startActivity(HousingIntent);
    }

    //Communication Menu Activity
    public void CommunicationMenu(View cview) {
        Intent CommunicationIntent = new Intent(this, CommunicationActivity.class);
        startActivity(CommunicationIntent);
    }

    //Employment Menu Activity
    public void EmploymentMenu(View eview) {
        Intent EmploymentIntent = new Intent(this, EmploymentActivity.class);
        startActivity(EmploymentIntent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.fab:
                //when button is clicked
                public void onAccessibilityEvent (AccessibilityEvent even{   //Says screen content as it reads it in
                tts = new TextToSpeech(Log.v(TAG, String.format(
                        "onAccessibilityEvent: type = [ %s ], class = [ %s ], package = [ %s ], time = [ %s ], text = [ %s ]",
                        getEventType(event), event.getClassName(), event.getPackageName(),
                        event.getEventTime(), getEventText(event))), new TextToSpeech.OnInitListener() {
                    public void onInit(int status) {
                        if (status == TextToSpeech.SUCCESS) {
                            int ttsLang = tts.setLanguage(Locale.US);

                            Log.i("TTS", "Initialization success.");
                        } else {
                            Toast.makeText(getApplicationContext(), "TTS Initialization failed!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }
    }
}